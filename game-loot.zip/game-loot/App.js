import {AppRoutes} from "./src/routes/index"

export default function App() { 
  return (
      <AppRoutes/>
  );
}